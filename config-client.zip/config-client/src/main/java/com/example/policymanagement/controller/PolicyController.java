package com.example.policymanagement.controller;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.example.policymanagement.entity.Policy;
import com.example.policymanagement.repository.PolicyRepository;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * Controller for fetching user policies and update as required by the admin
 **/
@RestController
@RequestMapping("/api/policies")
public class PolicyController {
    @Autowired
    PolicyRepository policyRepository;
    private Logger logger = LoggerFactory.getLogger(this.getClass());


    /**
     * http://localhost:8090/api/policies/all
     * @return all policies for the admin
     */
    @GetMapping("/all")
    public List<Policy> list() {
        List<Policy>  policies= policyRepository.findAll();

        logger.info("Size of the policy {}", policies.size());

        for (Policy policy: policies) {
            logger.info("Policy {} ",policy);
        }
        return policies;
    };
    @GetMapping("/test")
    public List<Policy> testFew() {
        List<Policy>  policies=  new ArrayList<>();
        Policy policy = new Policy();
        policy.setPolicyName("Home Policy");
        policies.add(policy);

        policy = new Policy();
        policy.setPolicyName("Vehicle Policy");
        policies.add(policy);

        policy = new Policy();
        policy.setPolicyName("Medical Policy");
        policies.add(policy);



        logger.info("Size of the policy {}", policies.size());

        return policies;
    };

    /**
     * http://localhost:8090/api/policies/1
     * @param id - of one policy
     * @return the policy queries
     */
    @GetMapping("/{id}")
    public Policy findById(@PathVariable("id") long id) {
        return policyRepository.getOne(id);
    }

    
     // Save policy
     

    /**
     * Save a policy
     * @param policy
     * @return saved policy
     *{
     *     "id": 10,
     *     "policyName": "Home Policy",
     *     "detailedName": "Policy validated 1 year"
     * }
     * POST
     * http://localhost:8090/api/policies/
     */

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Policy save(@RequestBody @Validated Policy policy) {
        return policyRepository.save(policy);
    }
    
}
