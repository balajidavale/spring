package com.example.demo.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.http.MediaType;

import com.example.demo.domain.Book;


@FeignClient("book-service")
public interface BookeServiceProxy {
	
	@GetMapping(value = "/books" , produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Book> getAllBooks();
	
	
	
	@GetMapping(value = "/books/{id}" , produces = {MediaType.APPLICATION_JSON_VALUE})
	public Book getBookById(@PathVariable("id") Integer id);
	
	

}
