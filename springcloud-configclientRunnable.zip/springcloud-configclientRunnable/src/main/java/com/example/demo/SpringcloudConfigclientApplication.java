package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import com.example.demo.domain.Book;
import com.example.demo.repository.BookRepository;
@EnableEurekaClient

@SpringBootApplication
public class SpringcloudConfigclientApplication implements CommandLineRunner {
	
	
	
	@Autowired
	@Qualifier("bookRepository")
	private BookRepository bookRepository;

	public static void main(String[] args) {
		SpringApplication.run(SpringcloudConfigclientApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		bookRepository.save(new Book(101, "English", "balaji", 45001));
		bookRepository.save(new Book(102, "Kannada", "Davale", 30001));
		bookRepository.save(new Book(103, "Telugu", "nikhil", 20001));
		bookRepository.save(new Book(104, "Java Microservices", "Rita", 5000));
		System.out.println(bookRepository.findAll());
		
		
	}

}
