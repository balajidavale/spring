package com.example.demo.fallback;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import com.example.demo.domain.Book;
import com.example.demo.proxy.BookeServiceProxy;
@Component
public class BookServiceFallback implements BookeServiceProxy {

	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return Arrays.asList(new Book());
	}

	@Override
	public Book getBookById(Integer id) {
		// TODO Auto-generated method stub
		return new Book(id,"Demo","John",500);
	}

}
